requirements:
1. hierarchical objects: trees, monkies, baloons
2. camera tracking: cam tracks monkies floating away
3/4. new shape: kite shape, which is a six-sided, flat-shaded polygon
5. textured shape: textured kite shapes with drawn leaf pattern, which I stretched flat over each side
6. realtime speed: all animations are done as factors of animation_time, not previously stored transitions
7. framerate displayed in debug text box
Note: jungle music accompanies animation. plays automatically, so make sure sound is on.
